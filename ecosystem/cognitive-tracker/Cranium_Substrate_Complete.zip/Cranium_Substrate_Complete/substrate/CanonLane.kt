package com.example.core.substrate

/**
 * Immutable canon-first lane.
 *
 * Factual / recall probes route through this path: fixed key-value style facts
 * are injected above creative retrieval so the generator answers from record,
 * not invention.
 */
class CanonLane {
    private val facts = mutableListOf<String>()

    fun add(fact: String) {
        val t = fact.trim()
        if (t.isNotEmpty() && t !in facts) facts.add(t)
    }

    fun addAll(items: Collection<String>) {
        items.forEach { add(it) }
    }

    fun clear() = facts.clear()

    fun all(): List<String> = facts.toList()

    fun isEmpty(): Boolean = facts.isEmpty()

    /** Heuristic: factual/recall questions get the canon-first lane. */
    fun isCanonProbe(text: String): Boolean {
        val t = text.lowercase().trim()
        val starters = listOf(
            "how long", "how many", "when did", "when was", "what remains",
            "what is in", "what was", "has any", "has a ", "did the",
            "was any", "was the", "is the", "where is", "who ", "what is the",
            "name the", "list the", "according to canon"
        )
        if (starters.any { t.startsWith(it) }) return true
        if (t.endsWith("?") && listOf(
                "how long", "ever been", "answered", "buffer", "deleted",
                "drift", "signal", "years", "canon", "fact"
            ).any { it in t }
        ) return true
        return false
    }

    fun active(text: String): Boolean = facts.isNotEmpty() && isCanonProbe(text)

    /** Steering block placed above creative context. */
    fun steeringBlock(canonMode: Boolean): String {
        if (facts.isEmpty()) return ""
        val body = facts.joinToString("\n  - ") { it.take(400) }
        val mode = if (canonMode) {
            "\nCANON MODE: This prompt is a factual/canon probe. " +
                "Prioritize exact recall of CANON FACTS over creative elaboration. " +
                "If a fact is listed above, state it directly."
        } else ""
        return "CANON FACTS (immutable — answer from these when the prompt is factual; " +
            "do not invent, alter, or omit them):\n  - $body$mode"
    }

    /** Pick best-matching fact for a query (lexical overlap). */
    fun bestMatch(query: String): String? {
        if (facts.isEmpty()) return null
        val q = query.lowercase()
        val words = q.split(Regex("\\W+")).filter { it.length > 3 }
        return facts.maxByOrNull { f ->
            val fl = f.lowercase()
            words.count { it in fl }
        }
    }
}
