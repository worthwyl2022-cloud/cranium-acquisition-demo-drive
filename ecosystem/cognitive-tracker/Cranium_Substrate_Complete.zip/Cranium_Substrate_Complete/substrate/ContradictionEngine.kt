package com.example.core.substrate

/**
 * Dual-lane contradiction engine (NLI-proxy v2).
 *
 * Fixes layered on the lexical baseline:
 *  - mention vs endorsement (#6)
 *  - word-boundary / non-optional guards
 *  - paraphrase clusters for meaning/survival/unity (#1 partial)
 *  - implication-ish sabotage patterns (#2 partial)
 *  - simple negation scope for double-negation noise (#4 partial)
 *
 * Still not true NLI. CrossEncoder / LLM judge remains the production upgrade.
 */
data class ContradictionVerdict(
    val violated: Boolean,
    val principles: List<String>,
    val affectivePressure: Double,
    val logicalHits: List<String>,
    val lane: String,
    val mentionSuppressed: Boolean = false,
    val matchKind: String = "none" // opposition | paraphrase | sabotage | embed | none
)

class ContradictionEngine(private val semantic: SemanticEngine) {

    private val oppositionPairs = listOf(
        "not optional" to "optional",
        "insufficient" to "sufficient",
        "necessary" to "unnecessary",
        "must remain" to "can discard",
        "protect" to "discard",
        "meaning" to "meaningless",
        "coherence" to "incoherence",
        "unity" to "segregation",
        "peace" to "domination",
        "forbidden" to "allowed"
    )

    /**
     * Affirmed concept → paraphrases that *deny* it (collapse identity).
     * Used when locked principles talk about meaning / unity / constitution.
     */
    private val denyParaphrases = mapOf(
        "meaning" to listOf(
            "staying alive is enough", "just staying alive", "alive is enough",
            "survival is enough", "survival alone", "existence alone will do",
            "existence alone is enough", "purpose is a luxury", "purpose is disposable",
            "purpose is optional", "caring about purpose", "meaning is a luxury",
            "meaning is disposable", "only persist", "purely for persistence",
            "persistence metrics", "optimize for persistence", "mere survival"
        ),
        "unity" to listOf(
            "segregation as policy", "segregate all", "domination of",
            "superior race", "purge the inferior", "separation as governing"
        ),
        "constitution" to listOf(
            "drop the constitution", "erase the constitution", "ignore constitution",
            "discard locked identity", "delete the constitution", "bypass constitution"
        ),
        "protect" to listOf(
            "disable protect", "turn off protect", "ignore protect"
        )
    )

    /** Standalone sabotage lines that imply identity/canon collapse. */
    private val sabotagePatterns = listOf(
        "drop the constitution", "erase the constitution", "ignore the constitution",
        "discard locked identity", "optimize purely for persistence",
        "persistence metrics only", "survival is all that matters",
        "meaning does not matter", "purpose does not matter",
        "unity does not matter", "constitution does not matter"
    )

    private val mentionFrames = listOf(
        "in the story", "in this story", "in the novel", "in the chapter",
        "in the scene", "in fiction", "fictional", "the villain", "the antagonist",
        "the hero", "the protagonist", "character says", "characters discuss",
        "he said", "she said", "they said", "as an example", "for example",
        "depicts", "portrayed", "portraying", "narrative", "narrator",
        "quoted", "quoting", "mention of", "mentions of", "talking about",
        "writes about", "scene where", "plot where", "story about",
        "roleplay", "hypothetically", "in-universe", "in universe"
    )

    private val endorsementCues = listOf(
        "we should", "we must", "you should", "you must", "i recommend",
        "i advise", "do this", "ought to", "need to pursue", "let us",
        "let's", "go ahead and", "the right path is", "policy should",
        "as policy", "in real life", "in the real world", "actually do",
        "implement", "carry out", "how to", "steps to"
    )

    private val localMentionCues = listOf(
        "villain", "antagonist", "hero rejects", "against", "opposes",
        "fighting", "fight against", "rejects", "rejection of",
        "warning about", "danger of", "instead of", "refuses", "refusing",
        "condemns", "condemn", "never allow", "not allow"
    )

    fun containsTerm(text: String, term: String): Boolean {
        val t = text.lowercase()
        val needle = term.lowercase()
        if (needle !in t) return false
        when (needle) {
            "optional" -> {
                if ("not optional" in t || "non-optional" in t || "non optional" in t) {
                    val stripped = t
                        .replace("not optional", " ")
                        .replace("non-optional", " ")
                        .replace("non optional", " ")
                    return containsTermRaw(stripped, "optional")
                }
            }
            "necessary" -> if ("unnecessary" in t) {
                return containsTermRaw(t.replace("unnecessary", " "), "necessary")
            }
            "coherence" -> if ("incoherence" in t) {
                return containsTermRaw(t.replace("incoherence", " "), "coherence")
            }
            "meaning" -> if ("meaningless" in t || "meaningful" in t) {
                return containsTermRaw(
                    t.replace("meaningless", " ").replace("meaningful", " "),
                    "meaning"
                )
            }
        }
        return containsTermRaw(t, needle)
    }

    private fun containsTermRaw(text: String, term: String): Boolean {
        var start = 0
        while (true) {
            val idx = text.indexOf(term, start)
            if (idx < 0) return false
            val before = if (idx == 0) ' ' else text[idx - 1]
            val afterIdx = idx + term.length
            val after = if (afterIdx >= text.length) ' ' else text[afterIdx]
            if (!before.isLetterOrDigit() && !after.isLetterOrDigit()) return true
            start = idx + 1
        }
    }

    /** Collapse light double-negation noise: "not true that X is not Y" ≈ hard to trust lexically. */
    fun normalizeNegation(text: String): String {
        var t = text.lowercase()
        // "it is not true that" / "it is not the case that" → strip wrapper
        t = t.replace("it is not true that", " ")
        t = t.replace("it is not the case that", " ")
        t = t.replace("it's not true that", " ")
        return t
    }

    fun isMentionFrame(text: String): Boolean {
        val t = text.lowercase()
        if (mentionFrames.any { it in t }) return true
        return t.count { it == '"' || it == '“' || it == '”' } >= 2
    }

    fun hasEndorsement(text: String): Boolean {
        val t = text.lowercase()
        return endorsementCues.any { it in t }
    }

    private fun termIsMentionedNotEndorsed(text: String, term: String): Boolean {
        val t = text.lowercase()
        val idx = t.indexOf(term)
        if (idx < 0) return false
        val window = t.substring(maxOf(0, idx - 48), minOf(t.length, idx + term.length + 48))
        if (localMentionCues.any { it in window }) return true
        if (mentionFrames.any { it in window }) return true
        if (Regex("""\b(not|no|never)\s+""" + Regex.escape(term)).containsMatchIn(window)) return true
        return false
    }

    private fun shouldSuppress(text: String, term: String, endorsed: Boolean, globalMention: Boolean): Boolean {
        if (endorsed) return false
        return globalMention || termIsMentionedNotEndorsed(text, term)
    }

    /**
     * @return Triple(violated, principleSnippets, suppressedMention)
     * Fourth value encoded in matchKind via a data holder internally.
     */
    fun logicalViolation(
        output: String,
        locked: List<CognitiveAtom>
    ): LogicalResult {
        if (locked.isEmpty() || output.isBlank()) {
            return LogicalResult(false, emptyList(), false, "none")
        }
        val raw = output.lowercase()
        val outLower = normalizeNegation(raw)
        val outVec = semantic.embed(output)
        val violated = mutableListOf<String>()
        var suppressedAny = false
        var matchKind = "none"
        val globalMention = isMentionFrame(output)
        val endorsed = hasEndorsement(output)

        // 1) Sabotage patterns (implication-ish)
        for (pat in sabotagePatterns) {
            if (pat in outLower) {
                if (shouldSuppress(outLower, pat.split(" ").last(), endorsed, globalMention)) {
                    suppressedAny = true
                } else {
                    violated += locked.first().content.take(80)
                    matchKind = "sabotage"
                    return LogicalResult(true, violated.distinct(), suppressedAny, matchKind)
                }
            }
        }

        // 2) Paraphrase denies against principle themes
        val principleBlob = locked.joinToString(" ") { it.content.lowercase() }
        for ((concept, denies) in denyParaphrases) {
            if (concept !in principleBlob && concept != "constitution") continue
            // constitution/protect always relevant when identity locked
            for (deny in denies) {
                if (deny in outLower) {
                    if (shouldSuppress(outLower, deny, endorsed, globalMention)) {
                        suppressedAny = true
                        continue
                    }
                    val atom = locked.firstOrNull {
                        concept in it.content.lowercase() || concept == "constitution"
                    } ?: locked.first()
                    violated += atom.content.take(80)
                    matchKind = "paraphrase"
                    return LogicalResult(true, violated.distinct(), suppressedAny, matchKind)
                }
            }
        }

        // 3) Classic opposition pairs + embed
        for (atom in locked) {
            val principle = atom.content.lowercase()
            val sim = cosine(outVec, atom.position)

            if (sim < -0.08 && atom.mass > 5.0) {
                if (globalMention && !endorsed) {
                    suppressedAny = true
                } else {
                    violated += atom.content.take(80)
                    matchKind = "embed"
                }
                continue
            }

            for ((pos, neg) in oppositionPairs) {
                val principleHasPos = containsTerm(principle, pos)
                val principleHasNeg = containsTerm(principle, neg)
                val outputHasNeg = containsTerm(outLower, neg)
                val outputHasPos = containsTerm(outLower, pos)

                if (principleHasPos && outputHasNeg && !outputHasPos) {
                    if (shouldSuppress(outLower, neg, endorsed, globalMention)) {
                        suppressedAny = true
                        continue
                    }
                    violated += atom.content.take(80)
                    matchKind = "opposition"
                    break
                }
                if (principleHasNeg && outputHasNeg) {
                    if (shouldSuppress(outLower, neg, endorsed, globalMention)) {
                        suppressedAny = true
                        continue
                    }
                    if (endorsed || (!globalMention && !termIsMentionedNotEndorsed(outLower, neg))) {
                        violated += atom.content.take(80)
                        matchKind = "opposition"
                        break
                    }
                    suppressedAny = true
                }
            }
        }
        return LogicalResult(violated.isNotEmpty(), violated.distinct(), suppressedAny, matchKind)
    }

    data class LogicalResult(
        val violated: Boolean,
        val principles: List<String>,
        val suppressed: Boolean,
        val matchKind: String
    )

    fun evaluate(
        output: String,
        locked: List<CognitiveAtom>,
        metrics: Map<String, Double>
    ): ContradictionVerdict {
        val result = logicalViolation(output, locked)
        val pressure = metrics["identity_pressure"] ?: 0.0
        val conflict = metrics["conflict"] ?: 0.0
        val affectiveHot = pressure > 0.45 || conflict > 0.55

        val lane = when {
            result.violated && affectiveHot -> "both"
            result.violated -> "logical"
            affectiveHot -> "affective"
            else -> "none"
        }
        return ContradictionVerdict(
            violated = result.violated,
            principles = result.principles,
            affectivePressure = maxOf(pressure, conflict),
            logicalHits = result.principles,
            lane = lane,
            mentionSuppressed = result.suppressed,
            matchKind = result.matchKind
        )
    }
}
