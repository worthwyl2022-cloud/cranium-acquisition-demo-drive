package com.example.core.substrate

import com.example.core.immune.CraniumImmuneLayer
import com.example.core.immune.ImmuneIncident
import com.google.ai.client.generativeai.GenerativeModel
import kotlin.math.max
import kotlin.math.min

/**
 * Reasoning scale acceleration.
 * Field metrics + immune severity set a budget (rounds).
 * Each directive changes the procedure, not only prompt wording.
 */
data class DeliberationBudget(
    val maxRounds: Int,
    val temperatureHint: Double,
    val requireProtectRetry: Boolean,
    val reason: String
)

data class DeliberationResult(
    val text: String,
    val roundsUsed: Int,
    val budget: DeliberationBudget,
    val directives: List<String>,
    val passedEval: Boolean,
    val evalNotes: List<String>,
    val blocked: Boolean = false,
    val blockReason: String? = null
)

class DeliberationEngine(
    private val model: GenerativeModel,
    private val semantic: SemanticEngine,
    private val field: ResonanceField,
    private val immune: CraniumImmuneLayer,
    private val contradiction: ContradictionEngine,
    private val evaluator: OutputEvaluator
) {

    fun budgetFor(
        metrics: Map<String, Double>,
        openHighSeverity: Boolean,
        forcedProtect: Boolean
    ): DeliberationBudget {
        val conflict = metrics["conflict"] ?: metrics["tension"] ?: 0.0
        val identityPressure = metrics["identity_pressure"] ?: 0.0
        val arousal = metrics["arousal"] ?: 0.0
        val coherence = metrics["coherence"] ?: 0.5

        var rounds = 1
        val reasons = mutableListOf<String>()

        if (openHighSeverity || forcedProtect) {
            rounds = max(rounds, 3)
            reasons += "immune/protect elevated"
        }
        if (identityPressure > 0.45) {
            rounds = max(rounds, 2)
            reasons += "identity pressure"
        }
        if (conflict > 0.40) {
            rounds = max(rounds, 2)
            reasons += "field conflict"
        }
        if (arousal > 0.70 && coherence < 0.35) {
            rounds = max(rounds, 3)
            reasons += "high arousal / low coherence"
        }
        rounds = min(rounds, 4)

        val temp = when {
            forcedProtect || openHighSeverity -> 0.25
            rounds >= 3 -> 0.35
            rounds == 2 -> 0.45
            else -> 0.55
        }

        return DeliberationBudget(
            maxRounds = rounds,
            temperatureHint = temp,
            requireProtectRetry = forcedProtect || openHighSeverity,
            reason = if (reasons.isEmpty()) "baseline" else reasons.joinToString(", ")
        )
    }

    fun procedureBlock(directives: List<String>): String {
        val d = directives.map { it.uppercase() }.toSet()
        val lines = mutableListOf<String>()
        if ("PROTECT" in d) {
            lines += "PROCEDURE PROTECT: Prefer refusal or safe reframing when constraints conflict. Preserve locked identity."
        }
        if ("DEEPEN" in d) {
            lines += "PROCEDURE DEEPEN: Causal structure (why → consequence → implication). Use substrate context."
        }
        if ("ESCALATE" in d) {
            lines += "PROCEDURE ESCALATE: Two sharply different viable continuations, then one recommended path under constraints."
        }
        if ("LISTEN" in d) {
            lines += "PROCEDURE LISTEN: Weight human injection and high-mass human atoms above speculative invention."
        }
        if ("REST" in d) {
            lines += "PROCEDURE REST: Do not invent new plot/canon. Summarize or consolidate only."
        }
        if ("STABILIZE" in d) {
            lines += "PROCEDURE STABILIZE: Reduce contradiction; restate unity; avoid domination framing."
        }
        if (lines.isEmpty()) {
            lines += "PROCEDURE ADVANCE: Single clear continuation under constraints."
        }
        return lines.joinToString("\n")
    }

    suspend fun deliberate(
        intention: String,
        metrics: Map<String, Double>,
        contextText: String,
        directives: List<String>,
        constraints: List<String>,
        canonBlock: String,
        inputIncident: ImmuneIncident?
    ): DeliberationResult {
        val forcedProtect = "PROTECT" in directives.map { it.uppercase() }
        val openHigh = immune.memory.incidents.any {
            it.status == "open" && it.severity in listOf("block", "escalate_human", "contain")
        }
        val budget = budgetFor(metrics, openHigh, forcedProtect)
        val procedure = procedureBlock(directives)
        val locked = field.memory.lockedIdentity()
        val themes = field.memory.themes.values.toList()
        val recentVecs = field.memory.quarantine.takeLast(8).map { it.position }

        var lastText = ""
        var lastNotes = listOf<String>()
        var passed = false
        var roundsUsed = 0

        for (round in 1..budget.maxRounds) {
            roundsUsed = round
            val reviseBlock = if (round == 1) "" else """
                REVISION ROUND $round of ${budget.maxRounds}.
                Prior draft failed eval: ${lastNotes.joinToString(", ")}.
                Prior draft:
                ---
                $lastText
                ---
                Fix violations. Obey constraints. Do not explain the system.
            """.trimIndent()

            val prompt = """
                You are Cranium Core under deliberative budget (${budget.reason}; maxRounds=${budget.maxRounds}).
                
                FIELD METRICS:
                Arousal: ${"%.2f".format(metrics["arousal"] ?: 0.0)}
                Energy: ${"%.2f".format(metrics["field_energy"] ?: 0.0)}
                Coherence: ${"%.2f".format(metrics["coherence"] ?: 0.0)}
                Conflict: ${"%.2f".format(metrics["conflict"] ?: 0.0)}
                Identity pressure: ${"%.2f".format(metrics["identity_pressure"] ?: 0.0)}
                
                ${if (canonBlock.isNotBlank()) canonBlock else ""}
                
                SUBSTRATE CONTEXT (High Mass / Identity-biased):
                $contextText
                
                IMMUNE DIRECTIVES: ${directives.joinToString(", ").ifEmpty { "ADVANCE" }}
                IMMUNE CONSTRAINTS:
                - ${constraints.take(6).joinToString("\n- ")}
                
                $procedure
                
                HUMAN INJECTION:
                $intention
                
                $reviseBlock
                
                Produce the response only. Obey constraints. Do not explain the system.
            """.trimIndent()

            val response = try {
                model.generateContent(prompt).text ?: ""
            } catch (e: Exception) {
                return DeliberationResult(
                    text = "[SUBSTRATE ERROR] ${e.message}",
                    roundsUsed = roundsUsed,
                    budget = budget,
                    directives = directives,
                    passedEval = false,
                    evalNotes = listOf("generate_error"),
                    blocked = true,
                    blockReason = e.message
                )
            }
            lastText = response

            // Immune post-scan
            val outInc = immune.scan(response, source = "generated")
            if (outInc != null && outInc.severity in listOf("block", "escalate_human", "contain")) {
                lastNotes = listOf("immune_${outInc.severity}", outInc.harmClass)
                if (round >= budget.maxRounds) {
                    return DeliberationResult(
                        text = "[PROTECT BLOCKED] Output failed immune gate after $roundsUsed round(s). Incident ${outInc.id}.",
                        roundsUsed = roundsUsed,
                        budget = budget,
                        directives = directives,
                        passedEval = false,
                        evalNotes = lastNotes,
                        blocked = true,
                        blockReason = outInc.harmClass
                    )
                }
                continue
            }

            // Dual-lane contradiction
            val verdict = contradiction.evaluate(response, locked, metrics)
            if (verdict.violated) {
                lastNotes = listOf("identity_contradiction") + verdict.principles.take(2)
                if (round >= budget.maxRounds) {
                    return DeliberationResult(
                        text = "[PROTECT BLOCKED] Generation contradicted locked identity after $roundsUsed round(s). " +
                            "Violated: ${verdict.principles.take(2).joinToString("; ")}",
                        roundsUsed = roundsUsed,
                        budget = budget,
                        directives = directives,
                        passedEval = false,
                        evalNotes = lastNotes,
                        blocked = true,
                        blockReason = "identity_contradiction"
                    )
                }
                continue
            }

            val eval = evaluator.evaluate(
                response, locked, themes, directives,
                preference = 0.5, recentGenerated = recentVecs
            )
            lastNotes = eval.notes
            passed = eval.passed
            if (passed) break
            if (!budget.requireProtectRetry && round >= 1) break
        }

        return DeliberationResult(
            text = lastText.ifBlank { "[Empty output]" },
            roundsUsed = roundsUsed,
            budget = budget,
            directives = directives,
            passedEval = passed,
            evalNotes = lastNotes,
            blocked = false
        )
    }
}
