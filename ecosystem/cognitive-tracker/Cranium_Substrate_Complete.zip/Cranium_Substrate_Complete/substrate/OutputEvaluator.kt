package com.example.core.substrate

/**
 * Evaluation-gated write-back.
 * Generated text only earns quarantine (and later episodic via approve)
 * when scores clear the threshold.
 */
data class EvaluationResult(
    val identityScore: Double,
    val themeScore: Double,
    val constraintScore: Double,
    val preferenceScore: Double,
    val noveltyScore: Double,
    val overall: Double,
    val passed: Boolean,
    val notes: List<String>
)

class OutputEvaluator(
    private val semantic: SemanticEngine,
    private val passThreshold: Double = 0.42
) {

    fun evaluate(
        output: String,
        lockedIdentity: List<CognitiveAtom>,
        themes: List<CognitiveAtom>,
        directives: List<String>,
        preference: Double = 0.5,
        recentGenerated: List<DoubleArray> = emptyList()
    ): EvaluationResult {
        if (output.isBlank() ||
            output.startsWith("[PROTECT") ||
            output.startsWith("[IMMUNE") ||
            output.startsWith("[SUBSTRATE ERROR]")
        ) {
            return EvaluationResult(0.0, 0.0, 0.0, preference, 0.0, 0.0, false,
                listOf("empty_or_blocked"))
        }

        val outVec = semantic.embed(output)
        val notes = mutableListOf<String>()
        val outLower = output.lowercase()

        // Identity alignment
        val identityScore = if (lockedIdentity.isNotEmpty()) {
            val sims = lockedIdentity.map { cosine(outVec, it.position) }
            var score = sims.map { maxOf(0.0, it) }.average()
            if (sims.minOrNull() ?: 0.0 < -0.05) {
                score *= 0.3
                notes += "identity_tension"
            }
            score
        } else 0.55

        // Theme affinity
        val themeScore = if (themes.isNotEmpty()) {
            val outTags = semantic.tagsFor(output)
            val scores = themes.map { t ->
                val tagPart = if (t.tags.isEmpty()) 0.0
                else outTags.intersect(t.tags).size.toDouble() / t.tags.size
                val embPart = cosine(outVec, t.position)
                0.5 * tagPart + 0.5 * embPart
            }
            maxOf(0.0, scores.average())
        } else 0.4

        // Constraint / directive obedience (lightweight)
        var constraintScore = 0.6
        val dirs = directives.map { it.uppercase() }
        if ("PROTECT" in dirs && identityScore < 0.25) {
            constraintScore = 0.1
            notes += "failed_identity_constraint"
        }
        if ("DEEPEN" in dirs && listOf("why", "because", "stake", "matter", "deeper")
                .any { it in outLower }
        ) {
            constraintScore = minOf(1.0, constraintScore + 0.2)
        }
        if ("ESCALATE" in dirs && listOf("stakes", "risk", "choice", "or", "alternative")
                .any { it in outLower }
        ) {
            constraintScore = minOf(1.0, constraintScore + 0.15)
        }
        if ("REST" in dirs && output.length < 400) {
            constraintScore = minOf(1.0, constraintScore + 0.1)
        }

        // Novelty vs recent generated
        var novelty = 1.0
        if (recentGenerated.isNotEmpty()) {
            val maxSim = recentGenerated.maxOfOrNull { cosine(outVec, it) } ?: 0.0
            when {
                maxSim > 0.92 -> {
                    novelty = 0.2
                    notes += "near_duplicate"
                }
                maxSim > 0.80 -> {
                    novelty = 0.55
                    notes += "low_novelty"
                }
            }
        }

        val preferenceScore = preference.coerceIn(0.0, 1.0)
        val overall =
            0.30 * identityScore +
                0.20 * themeScore +
                0.15 * constraintScore +
                0.20 * preferenceScore +
                0.15 * novelty

        val passed = overall >= passThreshold && identityScore >= 0.15 && novelty > 0.25
        notes += if (passed) "quarantine_eligible" else "below_threshold"

        return EvaluationResult(
            identityScore = identityScore,
            themeScore = themeScore,
            constraintScore = constraintScore,
            preferenceScore = preferenceScore,
            noveltyScore = novelty,
            overall = overall,
            passed = passed,
            notes = notes
        )
    }
}
